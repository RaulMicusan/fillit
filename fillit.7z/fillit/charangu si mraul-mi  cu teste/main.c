/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:31:05 by charangu          #+#    #+#             */
/*   Updated: 2018/01/18 16:31:08 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int	main(int argc, char **argv)
{
	char	*str;
	int		nb_tetriminos;

	if (!ft_read(argc, argv))
		return (0);
	str = ft_read(argc, argv);
	nb_tetriminos = ft_nb_tetriminos(str);
	if (ft_verif_tetriminos(str) != 0)
	{
		ft_putstr("error\n");
		return (0);
	}
	ft_rezolva(str);
	return (0);
}
