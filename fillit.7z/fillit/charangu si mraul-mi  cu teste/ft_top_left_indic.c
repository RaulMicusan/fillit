/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_top_left_indic.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:30:08 by charangu          #+#    #+#             */
/*   Updated: 2018/01/18 16:30:12 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

t_position	*ft_mergi_la_zero(t_position *tetriminos, int nb_tetriminos)
{
	int i;
	int k;

	i = 1;
	k = 0;
	while (k < nb_tetriminos)
	{
		tetriminos[k].x[i] = tetriminos[k].x[i] - tetriminos[k].x[0];
		tetriminos[k].y[i] = tetriminos[k].y[i] - tetriminos[k].y[0];
		i++;
		if (i > 3)
		{
			tetriminos[k].x[0] = 0;
			tetriminos[k].y[0] = 0;
			i = 1;
			k++;
		}
	}
	return (tetriminos);
}
