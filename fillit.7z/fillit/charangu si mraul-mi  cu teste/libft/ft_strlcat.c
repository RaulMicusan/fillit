/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 18:55:47 by charangu          #+#    #+#             */
/*   Updated: 2017/12/13 12:49:43 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	char	*dstp;
	char	*srcp;
	int		s;
	size_t	dlen;

	dstp = (char*)dst;
	srcp = (char*)src;
	s = size;
	while (s-- != 0 && *dstp != '\0')
		dstp++;
	dlen = dstp - dst;
	s = size - dlen;
	if (s == 0)
		return (dlen + ft_strlen(srcp));
	while (*srcp)
	{
		if (s-- > 1)
			*dstp++ = *srcp;
		srcp++;
	}
	*dstp = '\0';
	return (dlen + (srcp - src));
}
