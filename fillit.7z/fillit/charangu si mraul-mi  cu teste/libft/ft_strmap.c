/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 19:00:23 by charangu          #+#    #+#             */
/*   Updated: 2017/12/14 21:50:43 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmap(char const *s, char (*f)(char))
{
	char			*new;
	unsigned int	i;

	if (s && f)
	{
		new = ft_stralloc(s);
		if (new)
		{
			i = -1;
			while (s[++i])
				if (s[i])
					new[i] = f(s[i]);
			new[i] = '\0';
		}
		return (new);
	}
	return (NULL);
}
