/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 19:24:07 by charangu          #+#    #+#             */
/*   Updated: 2017/12/13 15:50:53 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	ft_count_words(char *str, char c)
{
	size_t		i;
	char		*s;

	i = 0;
	s = str;
	while (*s)
	{
		while (*s == c)
			s++;
		if (*s != c && *s)
		{
			i++;
			while (*s++ != c && *s)
				;
		}
	}
	return (i);
}

char			**ft_strsplit(char const *s, char c)
{
	char		**result;
	char		*src;
	size_t		wc;
	size_t		lc;

	if (!s)
		return (NULL);
	src = (char*)s;
	wc = ft_count_words(src, c);
	if (!(result = (char**)malloc(sizeof(char*) * (wc + 1))))
		return (NULL);
	while (wc-- >= 1)
	{
		lc = 0;
		while (*src == c && *src)
			src++;
		while (src[lc] != c && src[lc] != '\0')
			lc++;
		*result = ft_strsub(src, 0, lc);
		result++;
		src += lc;
	}
	*result = 0;
	return (result - (ft_count_words((char*)s, c)));
}
