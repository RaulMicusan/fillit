/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 19:24:42 by charangu          #+#    #+#             */
/*   Updated: 2017/12/07 21:56:19 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *big, const char *little)
{
	char	*it1;
	char	*it2;

	if (!*little)
		return ((void *)big);
	while (*big)
	{
		if (*big == *little)
		{
			it1 = (void *)big + 1;
			it2 = (void *)little + 1;
			while (*it1 && *it2 && *it1 == *it2)
			{
				++it1;
				++it2;
			}
			if (!*it2)
				return ((void *)big);
		}
		big++;
	}
	return (NULL);
}
