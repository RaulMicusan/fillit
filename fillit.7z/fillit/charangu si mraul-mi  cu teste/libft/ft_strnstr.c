/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 19:18:48 by charangu          #+#    #+#             */
/*   Updated: 2017/12/07 21:58:48 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, size_t n)
{
	size_t	iter;
	char	*temp1;
	char	*temp2;

	if (!*little)
		return ((void *)big);
	while (n-- && *big)
	{
		if (*big == *little)
		{
			iter = n;
			temp1 = (void *)big + 1;
			temp2 = (void *)little + 1;
			while (iter-- && *temp1 && *temp2 && *temp1 == *temp2)
			{
				++temp1;
				++temp2;
			}
			if (!*temp2)
				return ((void *)big);
		}
		big++;
	}
	return (NULL);
}
