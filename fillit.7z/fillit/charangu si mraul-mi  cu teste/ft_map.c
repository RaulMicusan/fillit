/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:27:24 by charangu          #+#    #+#             */
/*   Updated: 2018/01/19 11:24:13 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

char			**ft_umplere_tablou_final(int marime)
{
	int		i;
	int		j;
	char	**tablou;

	i = 0;
	j = 0;
	tablou = (char **)malloc((marime + 1) * sizeof(*tablou));
	while (i != marime + 1)
	{
		tablou[i] = (char*)malloc((marime + 1) * sizeof(tablou));
		i++;
	}
	i = 0;
	while (i < marime)
	{
		tablou[i][j] = '.';
		j++;
		if (j == marime)
		{
			tablou[i][j] = '\0';
			i++;
			j = 0;
		}
	}
	return (tablou);
}

void			ft_check_l_and_k(int *l, int *k)
{
	if (*l > 3)
	{
		*l = 0;
		*k = *k + 1;
	}
}

void			ft_check_i_and_cmpt(int *i, int *j, int *cmpt, char *str)
{
	if (str[*i] == '\n' && str[*i + 1] == '\n')
	{
		*j = 0;
		*i = *i + 1;
		*cmpt = *cmpt + 1;
	}
}

t_position		*ft_map(char *str, int i, int j, int k)
{
	int			l;
	int			cmpt;
	t_position	*tetriminos;

	tetriminos = (t_position *)malloc((ft_strlen(str) / 21 + 1)\
		* sizeof(t_position));
	l = 0;
	cmpt = 0;
	while (str[i] != '\0')
	{
		if (str[i] == '\n')
			j++;
		ft_check_i_and_cmpt(&i, &j, &cmpt, str);
		if (str[i] == '#')
		{
			tetriminos[k].x[l] = i - ((21 * cmpt) + (5 * j));
			tetriminos[k].y[l] = j;
			l++;
		}
		ft_check_l_and_k(&l, &k);
		i++;
	}
	return (tetriminos);
}

void			ft_remove_tetri(char **tablou, int k, int marime)
{
	int i;
	int j;

	i = 0;
	while (i <= marime)
	{
		j = 0;
		while (j <= marime)
		{
			if (tablou[i][j] == 'A' + k)
				tablou[i][j] = '.';
			j++;
		}
		i++;
	}
}
