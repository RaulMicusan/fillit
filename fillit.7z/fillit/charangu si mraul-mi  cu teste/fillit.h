/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:28:09 by charangu          #+#    #+#             */
/*   Updated: 2018/01/19 11:24:13 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLIT_H
# define FILLIT_H

# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <string.h>
# include <stdlib.h>
# include "libft/libft.h"
# define BUFFER 4096

typedef struct	s_position
{
	int	x[4];
	int	y[4];
}				t_position;

int				ft_check_char_tetriminos (char *str1, int i);
int				ft_check_sharps_tetriminos (char *str1, int i);
int				ft_check_links(char *str1, int i);
int				ft_count_links(char *str1, int i, int count_links);
char			***ft_init_matrice (char *str1);
int				ft_verif_tetriminos(char *str1);
void			ft_rezolva(char *str2);
int				**ft_stockindice(char ***tetriminos, char *str1);
t_position		*ft_map(char *str, int i, int j, int k);
void			ft_afisare_tab(char **tablou, int marime);
int				ft_nb_tetriminos(char *str2);
char			**ft_umplere_tablou_final(int marime);
t_position		*ft_mergi_la_zero(t_position *tetriminos, int nb_tetriminos);
void			ft_free_map(char **tablou, int marime);
void			ft_pune_piesa(char **tablou, t_position tetriminos, \
	int pos, int k);
int				ft_is_possible(char **tablou, t_position tetriminos,\
	int pos, int marime);
int				ft_sqrt(int nb);
char			*ft_read(int argc, char **argv);
int				ft_check_nb_tetri(char **tablou, int marime);
void			ft_remove_tetri(char **tablou, int k, int marime);
int				ft_print_tetri(char **tablou, t_position *tetriminos,\
	int nb_tetriminos, int k);
int				ft_check_newline(char *str1);
#endif
