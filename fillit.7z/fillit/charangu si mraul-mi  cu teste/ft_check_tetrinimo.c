/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_tetrinimo.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 15:26:13 by charangu          #+#    #+#             */
/*   Updated: 2018/01/18 15:45:09 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int		ft_is_possible(char **tablou, t_position tetriminos, \
	int pos, int marime)
{
	int		i;
	int		j;
	int		c;

	c = 0;
	i = pos / marime;
	j = pos % marime;
	while (c < 4)
	{
		if ((i + tetriminos.y[c] > marime - 1 ||\
			j + tetriminos.x[c] > marime - 1))
			return (0);
		if ((i + tetriminos.y[c]) < 0 || (j + tetriminos.x[c]) < 0)
			return (0);
		if ((tablou[i + tetriminos.y[c]][j + tetriminos.x[c]] != '.'))
			return (0);
		c++;
	}
	return (1);
}

int		ft_check_nb_tetri(char **tablou, int marime)
{
	int j;
	int i;
	int k;

	i = 0;
	k = 0;
	while (i < marime)
	{
		j = 0;
		while (j < marime)
		{
			if (tablou[i][j] == 'A' + k)
			{
				k++;
				i = 0;
				j = 0;
			}
			j++;
		}
		i++;
	}
	return (k);
}

void	ft_pune_piesa(char **tablou, t_position tetriminos, int pos, int k)
{
	int i;
	int j;
	int p;
	int marime;

	p = 0;
	marime = ft_strlen(tablou[0]);
	i = pos / marime;
	j = pos % marime;
	while (p < 4)
	{
		tablou[i + tetriminos.y[p]][j + tetriminos.x[p]] = 'A' + k;
		p++;
	}
}

int		ft_print_tetri(char **tablou, t_position *tetriminos, \
	int nb_tetriminos, int k)
{
	int i;
	int j;
	int pos;
	int marime;

	marime = ft_strlen(tablou[0]);
	pos = 0;
	i = pos / marime;
	j = pos % marime;
	if (ft_check_nb_tetri(tablou, marime) == nb_tetriminos)
		return (1);
	while (pos <= marime * marime)
	{
		if (ft_is_possible(tablou, tetriminos[k], pos, marime))
		{
			ft_pune_piesa(tablou, tetriminos[k], pos, k);
			if (ft_print_tetri(tablou, tetriminos, nb_tetriminos, k + 1))
				return (1);
			ft_remove_tetri(tablou, k, marime);
		}
		pos++;
	}
	return (0);
}

void	ft_rezolva(char *str)
{
	int			marime;
	char		**tablou;
	int			nb_tetriminos;
	int			i;
	t_position	*tetriminos;

	i = 1;
	tetriminos = ft_map(str, 0, 0, 0);
	nb_tetriminos = ft_nb_tetriminos(str);
	tetriminos = ft_mergi_la_zero(tetriminos, nb_tetriminos);
	marime = ft_sqrt(nb_tetriminos) * 2 - 1;
	tablou = ft_umplere_tablou_final(marime);
	while (ft_print_tetri(tablou, tetriminos, nb_tetriminos, 0) == 0)
	{
		ft_free_map(tablou, marime + i);
		tablou = ft_umplere_tablou_final(marime + i);
		ft_print_tetri(tablou, tetriminos, nb_tetriminos, 0);
		i++;
	}
	ft_afisare_tab(tablou, marime + i - 1);
	free(tablou);
}
