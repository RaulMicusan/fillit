/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_afisare.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:29:18 by charangu          #+#    #+#             */
/*   Updated: 2018/01/19 11:24:13 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(const char *src)
{
	int i;

	i = 0;
	while (src[i] != '\0')
	{
		ft_putchar((char)src[i]);
		i++;
	}
}

void	ft_afisare_tab(char **tablou, int marime)
{
	int	i;

	i = 0;
	while (i < marime)
	{
		ft_putstr(tablou[i]);
		ft_putchar('\n');
		i++;
	}
	ft_putstr(tablou[i]);
}

void	ft_free_map(char **tablou, int marime)
{
	int		i;

	i = 0;
	while (i < marime)
	{
		free(tablou[i]);
		i++;
	}
	free(tablou);
}
