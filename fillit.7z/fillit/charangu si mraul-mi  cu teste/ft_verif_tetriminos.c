/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_verif_tetriminos.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/18 16:30:30 by charangu          #+#    #+#             */
/*   Updated: 2018/01/18 19:33:15 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int	ft_verif_tetriminos(char *str1)
{
	int		i;

	i = 0;
	if (ft_check_char_tetriminos(str1, i) != 1)
		return (1);
	if (ft_check_sharps_tetriminos(str1, i) != 1)
		return (1);
	if (ft_check_links(str1, i) != 1)
	{
		return (1);
	}
	if (ft_check_newline(str1) != 1)
	{
		return (1);
	}
	return (0);
}
